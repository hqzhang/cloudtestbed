/**
 * @file exception.h
 * exception model base classes.
 **/

#ifndef	_EXCEPTION_H_
#define	_EXCEPTION_H_



#include <exception>
#include <string>
namespace bbt {

/**
 * Mainline exception handler, this is the root for all  C++
 * @short Base exception class for all C++ exceptions.
 */
class Exception : public std::exception 
{
private:
	std::string _what;

public:
	Exception(const std::string& what_arg) throw();
	virtual ~Exception() throw();
	virtual const char *getString() const; 
	virtual const char *what() const throw() { return _what.c_str(); };
};

/**
 * A sub-hierarchy for all C++ I/O related classes.
 *
 * @short I/O operation exception hierarchy.
 */
class IOException : public Exception
{
public:
	IOException(const std::string &what_arg) throw();
	virtual ~IOException() throw();
};


}; //end of namespace 

#endif
