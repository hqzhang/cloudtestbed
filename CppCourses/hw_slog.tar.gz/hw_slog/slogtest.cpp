#include "slog.h"
#include <iostream>
using namespace std;
int main()
{
    
    bbt::slog("MYTEST");
    bbt::slog.alert()<<"this is slog test!"<<endl;
    bbt::slog.error()<<"error message"<<endl;
    return 0;
}
