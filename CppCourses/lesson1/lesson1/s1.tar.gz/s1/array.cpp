#include <iostream>
using namespace std;

int main()
{
  int array[10]={1,2,3,4,5,6};
  for(int i=0;i<10;i++)
	cout << array[i];
  cout<<endl;


  return 0;
}
